#include <iostream>
#include "rlutil.h"
#include "reglas.h"
using namespace std;


int main(){


Bienvenida(30,5);
rlutil::anykey();
rlutil::cls();
//reglas
reglasJuego(30,10);













rlutil::locate(40,25);
return 0;
}
