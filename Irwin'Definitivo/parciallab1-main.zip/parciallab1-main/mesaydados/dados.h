#ifndef DADOS_H_INCLUDED
#define DADOS_H_INCLUDED
void dibujarCuadrado(int posX,int posY);
void dibujarDados(int ,int ,int);
void dibujarPuntos(int numero,int posX,int posY);


#endif // DADOS_H_INCLUDED
