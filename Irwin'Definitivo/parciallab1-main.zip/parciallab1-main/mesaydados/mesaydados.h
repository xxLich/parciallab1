#ifndef MESAYDADOS_H_INCLUDED
#define MESAYDADOS_H_INCLUDED

void fondoMesa(int , int );
void mesa(int , int);
void bordeMesa(int,int);
void dado10Caras(int,int,int);
void dosDadosSeisCaras(int, int, int);
void tresDadosSeisCaras(int, int, int);
void cincoDadosSeisCaras(int, int, int);

#endif // MESAYDADOS_H_INCLUDED
