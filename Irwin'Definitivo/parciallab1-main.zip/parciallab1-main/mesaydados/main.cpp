#include <iostream>
#include "mesaydados.h"
#include "rlutil.h"
#include "dados.h"
using namespace std;

int main(){


int dado=6;
dado10Caras(30,5,dado);
//dosDadosSeisCaras(30,5,dado);
//tresDadosSeisCaras(30,5,dado);
//cincoDadosSeisCaras(30,5,dado);
rlutil::locate(10,28);
return 0;
}
