#ifndef CREDITO_H_INCLUDED
#define CREDITO_H_INCLUDED

void mostrarCreditos();

#endif // CREDITO_H_INCLUDED
