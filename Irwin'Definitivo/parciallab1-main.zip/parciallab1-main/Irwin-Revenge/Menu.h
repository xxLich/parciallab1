#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

#include <iostream>
#include "rlutil.h"
#include "Menu.h"
#include "dado.h"
#include <string>


void drawMenu(int);


int selectOpciones(int & , int, int &);










///-----------------------------    FUNCIONES SECCION 2 JUGADORES

/// funcion principal
/// Corre el juego

void dosJugadores();














#endif // MENU_H_INCLUDED
