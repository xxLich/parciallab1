#ifndef MESAYDADOS_H_INCLUDED
#define MESAYDADOS_H_INCLUDED
#include "estructuras.h"


void dibujarMesa(int ,int,int );

void fondoMesa(int , int );
void mesa();
void bordeMesa(int,int);
void dado10Caras(int);
void dosDadosDiezCaras(jugadores[],int);
void tresDadosDiezCaras(jugadores[], int);
void cincoDadosSeisCaras(jugadores[], int);



#endif // MESAYDADOS_H_INCLUDED
