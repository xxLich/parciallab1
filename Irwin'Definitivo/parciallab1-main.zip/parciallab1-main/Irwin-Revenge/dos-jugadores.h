#ifndef DOS-JUGADORES_H_INCLUDED
#define DOS-JUGADORES_H_INCLUDED

#include<iostream>
#include "rlutil.h"
#include "Menu.h"
#include "dado.h"
#include "dos-jugadores.h"
#include <string>






void pedirDatos(string[], int);






#endif // DOS-JUGADORES_H_INCLUDED
