#ifndef REGLAS_H_INCLUDED
#define REGLAS_H_INCLUDED
void Bienvenida(int,int);
void asterisco (int, int);
void borde(int ,int);
void reglasJuego(int,int);
void regla1(int,int);
void regla2(int,int);



#endif // REGLAS_H_INCLUDED




