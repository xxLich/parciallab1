#include <iostream>
#include <chrono>
#include <thread>
#include "credito.h"





using namespace std;

void mostrarCreditos()
{
    int y = 25; // Posici�n inicial de los cr�ditos

    while (y >= 25) // Ajusta el valor final seg�n la cantidad deseada de desplazamiento
    {
        system("cls");

        for (int i = 0; i < y; i++)
        {
            cout << endl;
        }

       cout << "                                        ";
       cout<< char(201)<<char(205)<< char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(187);

        this_thread::sleep_for(chrono::milliseconds(800)); // Tiempo de visualizaci�n en cada posici�n

        y--;
    }
    while (y >= 24)
    {
        system("cls");

        for (int i = 0; i < y; i++)
        {
            cout << endl;
        }

       cout << "                                        ";
       cout<< char(201)<<char(205)<< char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(187)<<endl;
       cout << "                                        "<<char(186)<<"             Irwin's Revenge            "<<char(186);

        this_thread::sleep_for(chrono::milliseconds(800));

        y--;
    }
    while (y >= 23)
    {
        system("cls");

        for (int i = 0; i < y; i++)
        {
            cout << endl;
        }

       cout << "                                        ";
       cout<< char(201)<<char(205)<< char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(187)<<endl;
       cout << "                                        "<<char(186)<<"             Irwin's Revenge            "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186);

        this_thread::sleep_for(chrono::milliseconds(800));

        y--;
    }
    while (y >= 22)
    {
        system("cls");

        for (int i = 0; i < y; i++)
        {
            cout << endl;
        }

       cout << "                                        ";
       cout<< char(201)<<char(205)<< char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(187)<<endl;
       cout << "                                        "<<char(186)<<"             Irwin's Revenge            "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Programadores             "<<char(186);

        this_thread::sleep_for(chrono::milliseconds(800));

        y--;
    }
    while (y >= 21)
    {
        system("cls");

        for (int i = 0; i < y; i++)
        {
            cout << endl;
        }

       cout << "                                        ";
       cout<< char(201)<<char(205)<< char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(187)<<endl;
       cout << "                                        "<<char(186)<<"             Irwin's Revenge            "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Programadores             "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Ivan Agustin Leani          "<<char(186)<<endl;

        this_thread::sleep_for(chrono::milliseconds(800));

        y--;
    }
    while (y >= 20)
    {
        system("cls");

        for (int i = 0; i < y; i++)
        {
            cout << endl;
        }

       cout << "                                        ";
       cout<< char(201)<<char(205)<< char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(187)<<endl;
       cout << "                                        "<<char(186)<<"             Irwin's Revenge            "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Programadores             "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Ivan Agustin Leani          "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"          Lisandro Abel Lencina         "<<char(186)<<endl;

        this_thread::sleep_for(chrono::milliseconds(800));

        y--;
    }
    while (y >= 19)
    {
        system("cls");

        for (int i = 0; i < y; i++)
        {
            cout << endl;
        }

       cout << "                                        ";
       cout<< char(201)<<char(205)<< char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(187)<<endl;
       cout << "                                        "<<char(186)<<"             Irwin's Revenge            "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Programadores             "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Ivan Agustin Leani          "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"          Lisandro Abel Lencina         "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Josias Omar Olave           "<<char(186)<<endl;

        this_thread::sleep_for(chrono::milliseconds(800));

        y--;
    }
    while (y >= 18)
    {
        system("cls");

        for (int i = 0; i < y; i++)
        {
            cout << endl;
        }

       cout << "                                        ";
       cout<< char(201)<<char(205)<< char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(187)<<endl;
       cout << "                                        "<<char(186)<<"             Irwin's Revenge            "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Programadores             "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Ivan Agustin Leani          "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"          Lisandro Abel Lencina         "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Josias Omar Olave           "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;

        this_thread::sleep_for(chrono::milliseconds(800));

        y--;
    }
     while (y >= 17)
    {
        system("cls");

        for (int i = 0; i < y; i++)
        {
            cout << endl;
        }

       cout << "                                        ";
       cout<< char(201)<<char(205)<< char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(187)<<endl;
       cout << "                                        "<<char(186)<<"             Irwin's Revenge            "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Programadores             "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Ivan Agustin Leani          "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"          Lisandro Abel Lencina         "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Josias Omar Olave           "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                 Materia                "<<char(186)<<endl;

        this_thread::sleep_for(chrono::milliseconds(800));

        y--;
    }
    while (y >= 16)
    {
        system("cls");

        for (int i = 0; i < y; i++)
        {
            cout << endl;
        }

       cout << "                                        ";
       cout<< char(201)<<char(205)<< char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(187)<<endl;
       cout << "                                        "<<char(186)<<"             Irwin's Revenge            "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Programadores             "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Ivan Agustin Leani          "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"          Lisandro Abel Lencina         "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Josias Omar Olave           "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                 Materia                "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"      Laboratorio en Computacion I      "<<char(186)<<endl;

        this_thread::sleep_for(chrono::milliseconds(800));

        y--;
    }
    while (y >= 15)
    {
        system("cls");

        for (int i = 0; i < y; i++)
        {
            cout << endl;
        }

       cout << "                                        ";
       cout<< char(201)<<char(205)<< char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(187)<<endl;
       cout << "                                        "<<char(186)<<"             Irwin's Revenge            "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Programadores             "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Ivan Agustin Leani          "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"          Lisandro Abel Lencina         "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Josias Omar Olave           "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                 Materia                "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"      Laboratorio en Computacion I      "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;

        this_thread::sleep_for(chrono::milliseconds(800));

        y--;
    }
    while (y >= 14)
    {
        system("cls");

        for (int i = 0; i < y; i++)
        {
            cout << endl;
        }

       cout << "                                        ";
       cout<< char(201)<<char(205)<< char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(187)<<endl;
       cout << "                                        "<<char(186)<<"             Irwin's Revenge            "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Programadores             "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Ivan Agustin Leani          "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"          Lisandro Abel Lencina         "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Josias Omar Olave           "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                 Materia                "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"      Laboratorio en Computacion I      "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"               Profesores               "<<char(186)<<endl;

        this_thread::sleep_for(chrono::milliseconds(800));

        y--;
    }
    while (y >= 13)
    {
        system("cls");

        for (int i = 0; i < y; i++)
        {
            cout << endl;
        }

       cout << "                                        ";
       cout<< char(201)<<char(205)<< char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(187)<<endl;
       cout << "                                        "<<char(186)<<"             Irwin's Revenge            "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Programadores             "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Ivan Agustin Leani          "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"          Lisandro Abel Lencina         "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Josias Omar Olave           "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                 Materia                "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"      Laboratorio en Computacion I      "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"               Profesores               "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Angel  Simon              "<<char(186)<<endl;

        this_thread::sleep_for(chrono::milliseconds(800));

        y--;
    }
    while (y >= 12)
    {
        system("cls");

        for (int i = 0; i < y; i++)
        {
            cout << endl;
        }

       cout << "                                        ";
       cout<< char(201)<<char(205)<< char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(187)<<endl;
       cout << "                                        "<<char(186)<<"             Irwin's Revenge            "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Programadores             "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Ivan Agustin Leani          "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"          Lisandro Abel Lencina         "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Josias Omar Olave           "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                 Materia                "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"      Laboratorio en Computacion I      "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"               Profesores               "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Angel  Simon              "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"               Brian Lara               "<<char(186)<<endl;

        this_thread::sleep_for(chrono::milliseconds(800));

        y--;
    }
    while (y >= 11)
    {
        system("cls");

        for (int i = 0; i < y; i++)
        {
            cout << endl;
        }

       cout << "                                        ";
       cout<< char(201)<<char(205)<< char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(187)<<endl;
       cout << "                                        "<<char(186)<<"             Irwin's Revenge            "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Programadores             "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Ivan Agustin Leani          "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"          Lisandro Abel Lencina         "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Josias Omar Olave           "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                 Materia                "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"      Laboratorio en Computacion I      "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"               Profesores               "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Angel  Simon              "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"               Brian Lara               "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;

        this_thread::sleep_for(chrono::milliseconds(800));

        y--;
    }
    while (y >= 10)
    {
        system("cls");

        for (int i = 0; i < y; i++)
        {
            cout << endl;
        }

       cout << "                                        ";
       cout<< char(201)<<char(205)<< char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(187)<<endl;
       cout << "                                        "<<char(186)<<"             Irwin's Revenge            "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Programadores             "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Ivan Agustin Leani          "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"          Lisandro Abel Lencina         "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Josias Omar Olave           "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                 Materia                "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"      Laboratorio en Computacion I      "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"               Profesores               "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Angel  Simon              "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"               Brian Lara               "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                 Carrera                "<<char(186)<<endl;

        this_thread::sleep_for(chrono::milliseconds(800));

        y--;
    }
    while (y >= 9)
    {
        system("cls");

        for (int i = 0; i < y; i++)
        {
            cout << endl;
        }

       cout << "                                        ";
       cout<< char(201)<<char(205)<< char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(187)<<endl;
       cout << "                                        "<<char(186)<<"             Irwin's Revenge            "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Programadores             "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Ivan Agustin Leani          "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"          Lisandro Abel Lencina         "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Josias Omar Olave           "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                 Materia                "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"      Laboratorio en Computacion I      "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"               Profesores               "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Angel  Simon              "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"               Brian Lara               "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                 Carrera                "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"Tecnicatura universitaria enProgramacion"<<char(186)<<endl;

        this_thread::sleep_for(chrono::milliseconds(800));

        y--;
    }
    while (y >= 8)
    {
        system("cls");

        for (int i = 0; i < y; i++)
        {
            cout << endl;
        }

       cout << "                                        ";
       cout<< char(201)<<char(205)<< char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(187)<<endl;
       cout << "                                        "<<char(186)<<"             Irwin's Revenge            "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Programadores             "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Ivan Agustin Leani          "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"          Lisandro Abel Lencina         "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Josias Omar Olave           "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                 Materia                "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"      Laboratorio en Computacion I      "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"               Profesores               "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Angel  Simon              "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"               Brian Lara               "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                 Carrera                "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"Tecnicatura universitaria enProgramacion"<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;

        this_thread::sleep_for(chrono::milliseconds(800));

        y--;
    }
     while (y >= 0)
    {
        system("cls");

        for (int i = 0; i < y; i++)
        {
            cout << endl;
        }

       cout << "                                        ";
       cout<< char(201)<<char(205)<< char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(187)<<endl;
       cout << "                                        "<<char(186)<<"             Irwin's Revenge            "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Programadores             "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Ivan Agustin Leani          "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"          Lisandro Abel Lencina         "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"            Josias Omar Olave           "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                 Materia                "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"      Laboratorio en Computacion I      "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"               Profesores               "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"              Angel  Simon              "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"               Brian Lara               "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                 Carrera                "<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"Tecnicatura universitaria enProgramacion"<<char(186)<<endl;
       cout << "                                        "<<char(186)<<"                                        "<<char(186)<<endl;
       cout << "                                        ";
       cout<< char(200)<<char(205)<< char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205);
       cout << char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(205)<<char(188)<<endl;

        this_thread::sleep_for(chrono::milliseconds(800));

        y--;
    }
}
