#ifndef DADO_H_INCLUDED
#define DADO_H_INCLUDED







void dibujarCuadrado(int posX,int posY);
void dibujarDados(int ,int ,int);
void dibujarPuntos(int numero,int posX,int posY);



#endif // DADO_H_INCLUDED
