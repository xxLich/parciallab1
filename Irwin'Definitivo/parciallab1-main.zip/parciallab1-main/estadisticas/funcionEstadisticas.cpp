#include <iostream>
#include "estadisticas.h"
#include "rlutil.h"
using namespace std;

void estadisticas(int posX,int posY);

void estadisticas(int posX,int posY){
nombreJuego(1,1);
jugadores(1,1);


}

void nombreJuego(int posX,int posY){

cout<<"                      Irwin Revenge - Estadistica del juego - FASE FINAL"                      <<endl;
cout<<"----------------------------------------------------------------------------------------------"<<endl;

}
void jugadores(int posX,int posY){

cout<<"HITO                          NOMBRE JUGADOR1                                NOMBRE JUGADOR 2" <<endl;
cout<<"----------------------------------------------------------------------------------------------"<<endl;

cout<<"Estatuilla                       Puntos[] PD                                Puntos[] PDV"  <<endl;

cout<<"Estatuilla++                     Puntos[] PDV                               Puntos[]PDV"  <<endl;

cout<<"Ganador                          Puntos[] PDV                               Puntos[] PDV"  <<endl;

cout<<"Ganador++                        Puntos[] PDV                               Puntos[] PDV"  <<endl;

cout<<"Estatuilla                       Puntos[] PDV                               Puntos[] PDV"  <<endl;

cout<<"Lanzamiento                      Puntos[] PDV                               Puntos[] PDV"  <<endl;
cout<<"----------------------------------------------------------------------------------------------"<<endl;

cout<<"TOTAL                            TOTAL                                      TOTAL"               <<endl;

cout<<"----------------------------------------------------------------------------------------------"<<endl;
cout<<"GANADOR: JUGADOR"<<endl;

cout<<"Presionar ENTER para continuar"<<endl;
}
