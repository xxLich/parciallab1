#include <iostream>
#include "estadisticas.h"
#include "rlutil.h"
using namespace std;

int main(){

estadisticas(10,10);



return 0;
}
