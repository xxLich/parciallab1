#ifndef ESTADISTICAS_H_INCLUDED
#define ESTADISTICAS_H_INCLUDED
void estadisticas(int,int);
void nombreJuego(int ,int);
void jugadores(int,int);



#endif // ESTADISTICAS_H_INCLUDED
