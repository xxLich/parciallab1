# parciallab1
Trabajo practico Lab1 Irwin Revenge
Integrantes -> Omar Olave,Agustin Leani Y Lisandro Lencina.
- Se utulizo intento utilizar Trello para dividir las tareas pero al final lo descartamos.
- Utilizamos discord para la comunicacion, y wsp.
- Intetamos usar lo mas que podiamos GitHub para subir las funciones que haciamos asi despues lo juntabamos en un cpp y podiamos correr el programa
- A la hora de elegir las tareas decidimos repartirlas en..
- Fase de expedicion -> Ivan Leani
- Fase Final -> Omar Olave.
- Ordenar y decorar codigo -> Lisandro Lencina.
